let translations = {};
const htmlKeys = ["intro-all"];

$(document).ready(function () {
    const updateDynamicI18n = (selectedLang) => {
        $(".project-last-updated").each(function () {
            const key = $(this).data("i18n");
            const time = $(this).data("updated-time");
            const template = translations[selectedLang]?.[key];
            if (template) {
                $(this).text(template.replace("{{time}}", time));
            }
        });

        $(".bookmark-title").each(function () {
            const key = $(this).data("i18n");
            const translated = translations[selectedLang]?.[key];
            if (translated) {
                $(this).text(translated);
            }
        });
    };

    const applyTranslations = (lang) => {
        $("[data-i18n]").each(function () {
            const key = $(this).data("i18n");
            const translationContent = translations[lang]?.[key];

            if (!translationContent) return;

            if (this.tagName === "OPTGROUP") {
                // select2 optgroup 要直接設定 label 的值
                $(this).attr("label", translationContent);
                // 重新渲染 select2 下拉選單
                const $select = $("#core");
                if ($select.hasClass("select2-hidden-accessible")) {
                    $select.select2("destroy");
                }
                $select.select2();
            } else if (htmlKeys.includes(key)) {
                $(this).html(translationContent);
            } else {
                $(this).text(translationContent);
            }
        });
        updateDynamicI18n(lang);
    };

    window.translationsReady = new Promise((resolve) => {
        $.getJSON("/static/i18n/translations.json", function (data) {
            translations = data;
            resolve();

            $("#i18n-language").on("change", function () {
                const selectedLang = $(this).val();
                localStorage.setItem("selectedLanguage", selectedLang);
                location.reload();
                applyTranslations(selectedLang);
            });

            const savedLang =
                localStorage.getItem("selectedLanguage") ||
                $("#i18n-language").val();
            $("#i18n-language").val(savedLang);
            applyTranslations(savedLang);
        });
    });

    $(".left-container").click(function () {
        window.location.href = "/data-project";
    });

    var currentPage = window.location.pathname;

    // 檢查每個標籤的 href 屬性是否匹配當前頁面 URL
    $(".right-container .nav").each(function () {
        if ("/" + $(this).attr("id") + "/" === currentPage) {
            $(this).addClass("nav-active");
        } else {
            $(this).removeClass("nav-active");
        }
    });

    $(document).ready(function () {
        const projectName = getProjectNameFromUrl();
        if (projectName) {
            $("#current-project").text(projectName);
        } else {
            $(".project-title").addClass("d-none");
        }
    });
});

function getProjectNameFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("project_name");
}
